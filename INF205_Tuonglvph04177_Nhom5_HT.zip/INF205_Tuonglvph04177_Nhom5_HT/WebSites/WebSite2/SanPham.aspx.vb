﻿
Partial Class SanPham
    Inherits System.Web.UI.Page

End Class
