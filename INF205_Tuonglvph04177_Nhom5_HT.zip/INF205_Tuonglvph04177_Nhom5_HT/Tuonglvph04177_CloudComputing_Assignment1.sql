-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2016-09-23 14:43:24.764

-- tables
-- Table: ChiTiet_HoaDon
CREATE TABLE ChiTiet_HoaDon (
    MaCTHD int  NOT NULL,
    MaHD int  NOT NULL,
    MaSP int  NOT NULL,
    SoLuong int  NOT NULL,
    CONSTRAINT ChiTiet_HoaDon_pk PRIMARY KEY  (MaCTHD)
);

-- Table: HoaDon
CREATE TABLE HoaDon (
    MaHD int  NOT NULL,
    MaKH int  NOT NULL,
    DonHangSo varchar(12)  NOT NULL,
    CONSTRAINT HoaDon_pk PRIMARY KEY  (MaHD)
);

-- Table: KhachHang
CREATE TABLE KhachHang (
    MaKH int  NOT NULL,
    HoTen nvarchar(255)  NOT NULL,
    Diachi nvarchar(255)  NOT NULL,
    SDT varchar(15)  NOT NULL,
    Email varchar(255)  NOT NULL,
    CONSTRAINT KhachHang_pk PRIMARY KEY  (MaKH)
);

-- Table: LoaiSanPham
CREATE TABLE LoaiSanPham (
    MaLSP int  NOT NULL,
    TenLSP nvarchar(255)  NOT NULL,
    CONSTRAINT LoaiSanPham_pk PRIMARY KEY  (MaLSP)
);

-- Table: SanPham
CREATE TABLE SanPham (
    MaSP int  NOT NULL,
    MaLSP int  NOT NULL,
    DonViPhanLoai nchar(10)  NOT NULL,
    TenSP nvarchar(255)  NOT NULL,
    Gia decimal(12,2)  NOT NULL,
    MoTa nvarchar(1000)  NOT NULL,
    CONSTRAINT SanPham_pk PRIMARY KEY  (MaSP)
);

-- foreign keys
-- Reference: CHITIETHOADON_HOADON (table: ChiTiet_HoaDon)
ALTER TABLE ChiTiet_HoaDon ADD CONSTRAINT CHITIETHOADON_HOADON
    FOREIGN KEY (MaHD)
    REFERENCES HoaDon (MaHD);

-- Reference: CHITIETHOADON_SANPHAM (table: ChiTiet_HoaDon)
ALTER TABLE ChiTiet_HoaDon ADD CONSTRAINT CHITIETHOADON_SANPHAM
    FOREIGN KEY (MaSP)
    REFERENCES SanPham (MaSP);

-- Reference: HOADON_KHACHHANG (table: HoaDon)
ALTER TABLE HoaDon ADD CONSTRAINT HOADON_KHACHHANG
    FOREIGN KEY (MaKH)
    REFERENCES KhachHang (MaKH);

-- Reference: SANPHAM_LOAISANPHAM (table: SanPham)
ALTER TABLE SanPham ADD CONSTRAINT SANPHAM_LOAISANPHAM
    FOREIGN KEY (MaLSP)
    REFERENCES LoaiSanPham (MaLSP);

-- End of file.

